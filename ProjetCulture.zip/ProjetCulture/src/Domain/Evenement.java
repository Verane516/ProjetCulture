package Domain;

//Entity
public class Evenement {
	private Concert C1;
	private PieceDeTheatre PDT1;
	private int date;
}
